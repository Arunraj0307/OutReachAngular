import { Injectable } from '@angular/core';
import { getLocaleDateFormat } from '@angular/common';
import { HttpClient } from '@angular/common/http';  
import { HttpHeaders } from '@angular/common/http';  
import { Observable } from 'rxjs';  
import {AssociateDtlsModels} from '../model/Associate-Data';
import {MappingData} from '../model/Mapping-Data';
import {EventData} from '../model/Event-Data';
import {GenericMtrs} from '../model/genericMtrs-Data';
@Injectable({
  providedIn: 'root'
})
export class OutReachService {
  url = 'http://localhost:54958/api/values'; 
  constructor(private http: HttpClient) { }
  getExcelData(): Observable<AssociateDtlsModels[]> {  
    return this.http.get<AssociateDtlsModels[]>(this.url + '/GetValues');  
  }  
  createExcelData(associateDtl: AssociateDtlsModels[]) {  
    console.log(associateDtl);
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json'}) };  
    return this.http.post(this.url + '/InsertValues', associateDtl, httpOptions); 
  }
  createMappingData(mappingDtl: MappingData[]) {  
    console.log(mappingDtl);
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json'}) };  
    return this.http.post(this.url + '/InsertMappingValues', mappingDtl, httpOptions); 
  }
  createEventData(eventDtl: EventData[]) {  
    console.log(eventDtl);
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json'}) };  
    return this.http.post(this.url + '/InsertEventValues', eventDtl, httpOptions); 
  }
  getGenericMetricsData(): Observable<GenericMtrs[]> {  
    return this.http.get<GenericMtrs[]>(this.url + '/GetGenericMetrics');  
  }  

}
