import { Injectable } from '@angular/core';
import { getLocaleDateFormat } from '@angular/common';
import { HttpClient } from '@angular/common/http';  
import { HttpHeaders } from '@angular/common/http';  
import { Observable } from 'rxjs';  
import {AssociateDtlsModels} from '../model/Associate-Data';
@Injectable({
  providedIn: 'root'
})
export class OutReachService {
  url = 'http://localhost:54958/api/values'; 
  constructor(private http: HttpClient) { }
  getExcelData(): Observable<AssociateDtlsModels[]> {  
    return this.http.get<AssociateDtlsModels[]>(this.url + '/GetValues');  
  }  
  createExcelData(associateDtl: AssociateDtlsModels[]) {  
    console.log(associateDtl);
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json'}) };  
    return this.http.post(this.url + '/InsertValues', associateDtl, httpOptions); 
  }  

}
