export class GenericMtrs {
    month: string;
    volunteers: number;
    volunteeringHrs: number;
}