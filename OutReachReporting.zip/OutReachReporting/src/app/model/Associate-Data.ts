export class AssociateDtlsModels {
    AssociateId:string;
    AssociateName:string;
    Designation:string;
    Location:string;
    BusinessUnit:string;
    ContactNo:string;
}