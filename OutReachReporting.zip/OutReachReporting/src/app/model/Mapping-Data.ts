export interface MappingData {
    EventId:string;
    BaseLocation:string;
    BenifitName:string;
    CouncilName:string;
    EventName:string;
    EventDesc:string;
    EventDate:string;
    AssociateId:string;
    AssociateName:string;
    VoltrHrs:string;
    TravelHrs:string;
    LivesImpacts:string;
    BusinessUnit:string;
    Status:string;
    IIEPCategory:string;
}