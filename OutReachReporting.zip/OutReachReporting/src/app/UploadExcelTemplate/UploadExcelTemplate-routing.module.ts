import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {MainLayoutComponent} from '../layout/main-layout/main-layout.component';
import {UploadTemplateModuleComponent} from './UploadExcelTemplate.component';

const routes: Routes = [
  {
    path: 'UploadExcelTemplate',
    component: MainLayoutComponent,
    children: [
      { path: '', component: UploadTemplateModuleComponent }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UploadExcelTemplateRoutingModule { }
