import { Component, OnInit } from '@angular/core';
import * as XLSX from 'xlsx';
import {AssociateDtlsModels} from '../model/Associate-Data';
import {MappingData} from '../model/Mapping-Data';
import {EventData} from '../model/Event-Data';
import {OutReachService} from '../appService/outReach.service';
import { Observable } from 'rxjs'; 
type AOA = any[][];

@Component({
  selector: 'app-UploadExcelTemplate',
  templateUrl: './UploadExcelTemplate.component.html',
  styleUrls: ['./UploadExcelTemplate.component.css']
})
export class UploadTemplateModuleComponent implements OnInit {

  options = ['--Select--','Associate Template', 'Mapping Template', 'Event Template']  
  optionSelected: any;
  optionMessage: any;
  data: AOA = [ [1, 2], [3, 4] ];
  dataList:AOA = [];
  dbData:AssociateDtlsModels[] = [];
  dbMappingData:MappingData[] = [];
  dbEventData:EventData[] = [];
  allExcelData:AssociateDtlsModels[] = []; 
  constructor(private OutReachService:OutReachService) { }

  ngOnInit() {
  }
  onOptionsSelected(event){
    console.log(event); //option value will be sent as event
    this.optionSelected = event.target.value;
   }

  onFileChange(evt: any) {
    /* wire up file reader */
		const target: DataTransfer = <DataTransfer>(evt.target);
		if (target.files.length !== 1) throw new Error('Cannot use multiple files');
		const reader: FileReader = new FileReader();
		reader.onload = (e: any) => {
			/* read workbook */
			const bstr: string = e.target.result;
			const wb: XLSX.WorkBook = XLSX.read(bstr, {type: 'binary'});

			/* grab first sheet */
			const wsname: string = wb.SheetNames[0];
			const ws: XLSX.WorkSheet = wb.Sheets[wsname];

			/* save data */
			this.data = <AOA>(XLSX.utils.sheet_to_json(ws, {header: 1}));
			
			let values1 = [];
			let values2 = [];
			let years = [];
    
     if(this.optionSelected == 'Associate Template'){
      this.dataList = this.data;
      for(let i = 1; i< this.dataList.length;i++){
        //	for (let j = 0; j < this.dataList[i].length; j++) {
            const element = this.dataList[i];
            values1.push(element[2]);
            values2.push(element[2]);
            years.push(element[3].toString());
            this.dbData.push({AssociateId:element[0], AssociateName: element[1], Designation: element[2], Location: element[3], BusinessUnit: element[4], ContactNo: element[5]});
        //	}
        }
        this.OutReachService.createExcelData(this.dbData).subscribe((res)=>{
          console.log(res);     
        });
        this.optionMessage = 'Associate Detail Template Updated successfully..';
     }
     else if(this.optionSelected == 'Mapping Template')
     {this.dataList = this.data;
      for(let i = 1; i< this.dataList.length;i++){        
            const element = this.dataList[i];
            // values1.push(element[2]);
            // values2.push(element[2]);
            // years.push(element[3].toString());
            this.dbMappingData.push({EventId:element[0], BaseLocation: element[1], BenifitName: element[2], CouncilName: element[3], EventName: element[4], EventDesc: element[5], EventDate: element[6], AssociateId: element[7], AssociateName: element[8], VoltrHrs: element[9], TravelHrs: element[10], LivesImpacts: element[11], BusinessUnit: element[12], Status: element[13], IIEPCategory: element[14]});        
        }
        this.OutReachService.createMappingData(this.dbMappingData).subscribe((res)=>{
          console.log(res);     
        });
      this.optionMessage = 'Mapping Detail Template Updated successfully..';}
     else if(this.optionSelected == 'Event Template')
     {this.dataList = this.data;
      for(let i = 1; i< this.dataList.length;i++){        
        const element = this.dataList[i];
        // values1.push(element[2]);
        // values2.push(element[2]);
        // years.push(element[3].toString());
        this.dbEventData.push({EventId:element[0], Month: element[1], BaseLocation: element[2], BenifitName: element[3], VenueAddress: element[4], CouncilName: element[5], Project:element[6], Category: element[7], EventName: element[8], EventDescription: element[9], EventDate: element[10], TotalVolunteerNo: element[11], TotalVolunteerHrs:element[12], TotalTravelHrs: element[13], OverAllVolHrs: element[14], LivesImpacts: element[15], ActivityType: element[16], Status: element[17], AssociatePOCId: element[18], AssociatePOCName: element[19], AssociatePOCContNo: element[20], ModifiedBy: element[21]});        
    }
    this.OutReachService.createEventData(this.dbEventData).subscribe((res)=>{
      console.log(res);     
    });
      this.optionMessage = 'Event Detail Template Updated successfully..';};
    };  
    
//     this.OutReachService.getExcelData().subscribe((res)=>{
//       console.log(res);
//  });

    console.log(this.dbData);
   
    reader.readAsBinaryString(target.files[0]);
	}

}
