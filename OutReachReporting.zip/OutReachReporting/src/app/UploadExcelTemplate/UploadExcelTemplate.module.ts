import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UploadExcelTemplateRoutingModule } from './UploadExcelTemplate-routing.module';
import { UploadTemplateModuleComponent } from './UploadExcelTemplate.component';

@NgModule({
  imports: [
    CommonModule,
    UploadExcelTemplateRoutingModule
  ],
  declarations: [UploadTemplateModuleComponent]
})
export class UploadTemplateModule {   
 }
