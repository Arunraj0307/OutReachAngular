import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { genericMetricsComponent } from './genericMetrics.component';
import { GenericMetricsRoutingModule } from './genericMetrics-routing.module';
import { ChartsModule } from 'ng2-charts'

@NgModule({
  declarations: [
    genericMetricsComponent
  ],
  imports: [
    BrowserModule,
    GenericMetricsRoutingModule,
    ChartsModule
  ],
  providers: [],
  bootstrap: [genericMetricsComponent]
})
export class genericMetricsModule { }