import { Component, OnInit } from '@angular/core';
import {GenericMtrs} from '../model/genericMtrs-Data';
import {OutReachService} from '../appService/outReach.service';

@Component({
//   selector: 'app-root',
  templateUrl: './genericMetrics.component.html'
//   styleUrls: ['./app.component.css']
})
export class genericMetricsComponent {
  title = 'Bar Chart Example in Angular 4';

  constructor(private outReachService:OutReachService) {   }
    // ADD CHART OPTIONS. 
  chartOptions = {
    responsive: true    // THIS WILL MAKE THE CHART RESPONSIVE (VISIBLE IN ANY DEVICE).
  }

  
//   labels =  this.month;
labels =  ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
 
  // STATIC DATA FOR THE CHART IN JSON FORMAT.
  chartData = [
    {
      label: '',
      data: [], 
      backgroundColor: 'white'
    
    },
    { 
      label: '',
      data: [],
      backgroundColor: 'white'
    }
  ];

//   //CHART COLOR.
//   colors = [
//     { // 1st Year.
//       backgroundColor: 'rgba(77,83,96,0.2)'
//     },
//     { // 2nd Year.
//       backgroundColor: 'rgba(30, 169, 224, 0.8)' 
//     }
//   ]

  ngOnInit () {
    this.outReachService.getGenericMetricsData().subscribe((res)=>{
        // FILL THE CHART ARRAY WITH DATA.
        this.chartData.push({data:res.map((x)=>x.volunteers), label: 'Volunteer', backgroundColor: 'rgba(77,83,96,0.2)'  });
     this.chartData.push({data:res.map((x)=>x.volunteeringHrs), label: 'volunteeringHrs', backgroundColor: 'rgba(30, 169, 224, 0.8)' }) 
     console.log(res);

    })
};
  
  // CHART CLICK EVENT.
  onChartClick(event) {
    console.log(event);
  }
}