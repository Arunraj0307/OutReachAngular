import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import {LayoutModule} from './layout/layout.module';
import {RouterModule, Routes} from '@angular/router';
import {UploadTemplateModule} from './UploadExcelTemplate/UploadExcelTemplate.module';
import {RegisterModule} from './register/register.module';
import {LoginModule} from './login/login.module';
import { UploadTemplateModuleComponent } from './UploadExcelTemplate/UploadExcelTemplate.component';
import { HttpClientModule } from '@angular/common/http';  

const routes: Routes = [
  {
    path: '',
    redirectTo: '/UploadExcelTemplate',
    pathMatch: 'full'
  }
];

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes),
    LayoutModule,
    UploadTemplateModule,
    RegisterModule,
    LoginModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
