import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import {LayoutModule} from './layout/layout.module';
import {RouterModule, Routes} from '@angular/router';
import {UploadTemplateModule} from './UploadExcelTemplate/UploadExcelTemplate.module';
import {RegisterModule} from './register/register.module';
import {LoginModule} from './login/login.module';
import {genericMetricsModule} from './genericMetrics/genericMetrics.module';
import { HttpClientModule } from '@angular/common/http';  

const routes: Routes = [
  {
    path: '',
    redirectTo: '/genericMetrics',
    pathMatch: 'full'
  }
];

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes),
    LayoutModule,
    UploadTemplateModule,
    RegisterModule,
    LoginModule,
    genericMetricsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
